Erhu Tuner v1.2 with tighter UI boxes and spacing.
